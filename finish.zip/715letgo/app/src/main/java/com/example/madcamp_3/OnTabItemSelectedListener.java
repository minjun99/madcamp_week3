package com.example.madcamp_3;

public interface OnTabItemSelectedListener {
    public void onTabSelected(int position);
}

