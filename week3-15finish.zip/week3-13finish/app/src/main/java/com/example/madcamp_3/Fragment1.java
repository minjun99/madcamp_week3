package com.example.madcamp_3;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Fragment1 extends Fragment {
    FloatingActionButton button1,button2;
    public static VehicleAdapter adapter;
    public static Context mContext;
    RecyclerView recyclerView;
    static String vehicles;
    public static  List<Vehicle> vehiclecollection= new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment1, container,false);
        Context context = view.getContext();
        button1 = (FloatingActionButton) view.findViewById(R.id.buttontoalarm);
        button2 = (FloatingActionButton) view.findViewById(R.id.buttontoadd);
        recyclerView =(RecyclerView) view.findViewById(R.id.tab1recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter= new VehicleAdapter(context,vehiclecollection);
        //vehiclecollection.clear();
        recyclerView.setAdapter(adapter);

        get("http://143.248.36.141:3000/contactlist");
        //get("http://143.248.36.30:3000/contactlist");
        adapter.notifyDataSetChanged();

        button1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), GoToAlarm.class);
                startActivity(intent);
            }
        });

        button2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), AddVehicle.class);
                startActivity(intent);
            }
        });


        return view;
    }

    public static void get(String requestURL) {
        try {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(requestURL)
                    .build();

            //비동기 처리 (enqueue 사용)
            client.newCall(request).enqueue(new Callback() {
                //비동기 처리를 위해 Callback 구현
                @Override
                public void onFailure(Call call, IOException e) {
                    System.out.println("Sibal");
                    System.out.println("error + Connect Server Error is " + e.toString());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    vehicles=response.body().string();
                    System.out.println("Response Body is " + vehicles);
                   try {
                        JSONArray Jarray = new JSONArray(vehicles);
                       List<Vehicle> vehiclelist = new ArrayList<>();
                        if(Jarray!=null){
                            System.out.println(Jarray);
                            for(int i=0; i<Jarray.length();i++){
                                try{
                                    String vehiclename= Jarray.getJSONObject(i).getString("vehicle");
                                    String vehiclenum = Jarray.getJSONObject(i).getString("number");
                                    String vehicleid= Jarray.getJSONObject(i).getString("_id");
                                    Vehicle vehicle=new Vehicle(vehicleid,vehiclename,vehiclenum);
                                    vehiclelist.add(vehicle);
                                }catch (Exception e){
                                    e.printStackTrace();
                                }
                            }
                            vehiclecollection.clear();
                            vehiclecollection.addAll(vehiclelist);
                            System.out.println(vehiclecollection.size());
                        }
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
            });
        } catch (Exception e){
            System.err.println(e.toString());
        }

    }

}